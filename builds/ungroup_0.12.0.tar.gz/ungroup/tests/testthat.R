library(testthat)
library(ungroup)

test_check("ungroup")
